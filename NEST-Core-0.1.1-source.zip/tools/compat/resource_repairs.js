function initializeCoreMod() {
 var O=Java.type('org.objectweb.asm.Opcodes');
 var List=Java.type('org.objectweb.asm.tree.InsnList');
 var Var=Java.type('org.objectweb.asm.tree.VarInsnNode');
 var Call=Java.type('org.objectweb.asm.tree.MethodInsnNode');
 var Type=Java.type('org.objectweb.asm.tree.TypeInsnNode');
 return {'nest_rotten_wood_palette':{target:{type:'CLASS',name:'net.mehvahdjukaar.every_compat.api.PaletteStrategies'},transformer:function(node){
  var hooks=0;
  for(var i=0;i<node.methods.size();i++) {
   var m=node.methods.get(i);
   if(m.name!=='makePaletteFromChild')continue;
   var h=new List();h.add(new Var(O.ALOAD,2));h.add(new Var(O.ALOAD,0));
   h.add(new Call(O.INVOKESTATIC,'nest/compat/ResourceRepairs','paletteChild','(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;',false));
   h.add(new Var(O.ASTORE,2));m.instructions.insert(h);hooks++;
  }
  if(hooks!==1)throw new Error('NEST palette repair: expected one method, got '+hooks);
  return node;
 }},'nest_fish_molang':{target:{type:'CLASS',name:'software.bernie.geckolib.core.molang.MolangParser'},transformer:function(node){
  var hooks=0;
  for(var i=0;i<node.methods.size();i++){
   var m=node.methods.get(i);if(m.name!=='parseExpression')continue;
   var h=new List();h.add(new Var(O.ALOAD,0));
   h.add(new Call(O.INVOKESTATIC,'nest/compat/ResourceRepairs','molang','(Ljava/lang/String;)Ljava/lang/String;',false));
   h.add(new Var(O.ASTORE,0));m.instructions.insert(h);hooks++;
  }
  if(hooks!==1)throw new Error('NEST fish repair: expected one parser entry, got '+hooks);
  return node;
 }},'nest_single_color_leaves':{target:{type:'CLASS',name:'com.ordana.immersive_weathering.dynamicpack.ClientDynamicResourcesHandler'},transformer:function(node){
  var hooks=0;
  for(var i=0;i<node.methods.size();i++){
   var m=node.methods.get(i);
   for(var n=m.instructions.getFirst();n!==null;n=n.getNext()){
    if(n.getOpcode()===O.INVOKESTATIC && n.owner==='net/mehvahdjukaar/moonlight/api/resources/textures/TextureImage' && n.name==='open' && n.desc.indexOf('ResourceLocation;')>=0){
     var h=new List();h.add(new Call(O.INVOKESTATIC,'nest/compat/ResourceRepairs','leafTexture','(Ljava/lang/Object;)Ljava/lang/Object;',false));
     h.add(new Type(O.CHECKCAST,'net/minecraft/resources/ResourceLocation'));m.instructions.insertBefore(n,h);
    }
    if(n.getOpcode()!==O.INVOKEVIRTUAL || n.owner!=='net/mehvahdjukaar/moonlight/api/resources/textures/Palette' || n.name!=='increaseDown')continue;
    var cast=new Type(O.CHECKCAST,'net/mehvahdjukaar/moonlight/api/resources/textures/PaletteColor');
    m.instructions.insert(n,cast);
    m.instructions.set(n,new Call(O.INVOKESTATIC,'nest/compat/ResourceRepairs','increaseLeafPalette','(Ljava/lang/Object;)Ljava/lang/Object;',false));
    n=cast;hooks++;
   }
  }
  if(hooks!==2)throw new Error('NEST leaf repair: expected two expansions, got '+hooks);
  return node;
 }}};
}
