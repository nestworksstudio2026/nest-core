package nest.compat;
public final class ResourceRepairsTest {
 public static final class Wood {
  private final String id; private final Object stripped;
  public Wood(String id,Object stripped){this.id=id;this.stripped=stripped;}
  public String getId(){return id;}
  public Object getChild(String key){return stripped;}
 }
 public static final class Palette {
  public final int n; public int expansions=0;
  public Palette(int n){this.n=n;}
  public int size(){return n;}
  public Object getDarkest(){return "original";}
  public Object increaseDown(){expansions++;if(n<2)throw new IndexOutOfBoundsException();return "expanded";}
 }
 public static void main(String[] args){
  if(!ResourceRepairs.paletteChild("stripped_log",new Wood("betterarcheology:rotten",null)).equals("log"))throw new AssertionError();
  if(!ResourceRepairs.paletteChild("stripped_log",new Wood("minecraft:oak",null)).equals("stripped_log"))throw new AssertionError();
  if(!ResourceRepairs.paletteChild("stripped_log",new Wood("betterarcheology:rotten",new Object())).equals("stripped_log"))throw new AssertionError();
  var one=new Palette(1);if(!ResourceRepairs.increaseLeafPalette(one).equals("original")||one.expansions!=0)throw new AssertionError();
  var two=new Palette(2);if(!ResourceRepairs.increaseLeafPalette(two).equals("expanded")||two.expansions!=1)throw new AssertionError();
  String good="0*math.sin(query.anim_time)";if(!ResourceRepairs.molang(good).equals(good))throw new AssertionError();
  if(ResourceRepairs.molang("+math.sin(query.anim_time*360-90)*5").startsWith("+"))throw new AssertionError();
  System.out.println("PASS targeted palette fallbacks; valid expressions and other wood types preserved");
 }
}
