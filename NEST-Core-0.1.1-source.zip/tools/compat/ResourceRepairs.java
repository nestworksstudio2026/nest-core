package nest.compat;

/** Narrow repairs at resource decoding boundaries; no third-party assets bundled. */
public final class ResourceRepairs {
    private ResourceRepairs() {}
    public static String molang(String expression) {
        // Exact malformed expressions from Unusual Fish 1.1.10 only. Preserve all
        // other expressions, including valid zero products and unary operators.
        return switch (expression) {
            case "+math.sin(query.anim_time*360-90)*5" -> "math.sin(query.anim_time*360-90)*5";
            case "0math.sin(query.anim_time*720+60)*-10" -> "math.sin(query.anim_time*720+60)*-10";
            case "math.clamp(math.sin(query.anim_time*180-60)*0,0,20)2" -> "math.clamp(math.sin(query.anim_time*180-60)*0,0,20)";
            default -> expression;
        };
    }
    public static String paletteChild(String key, Object type) {
        if (!"stripped_log".equals(key)) return key;
        try {
            if ("betterarcheology:rotten".equals(String.valueOf(type.getClass().getMethod("getId").invoke(type)))
                && type.getClass().getMethod("getChild", String.class).invoke(type, key) == null)
                return "log";
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("NEST: incompatible palette API", ex);
        }
        return key;
    }
    public static Object increaseLeafPalette(Object palette) {
        try {
            int size = ((Number)palette.getClass().getMethod("size").invoke(palette)).intValue();
            return palette.getClass().getMethod(size == 1 ? "getDarkest" : "increaseDown").invoke(palette);
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("NEST: leaf palette expansion failed", ex);
        }
    }
    public static Object leafTexture(Object location) {
        if (!"biomesoplenty:block/null_leaves".equals(String.valueOf(location))) return location;
        try {
            return location.getClass().getConstructor(String.class).newInstance("biomesoplenty:block/null_overlay");
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("NEST: leaf texture lookup failed", ex);
        }
    }
}
