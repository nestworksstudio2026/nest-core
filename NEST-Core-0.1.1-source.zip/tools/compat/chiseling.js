function initializeCoreMod() {
 var O=Java.type('org.objectweb.asm.Opcodes');
 return {'nest_stone_chiseling':{target:{type:'CLASS',name:'net.mehvahdjukaar.stone_zone.modules.rechiseled.RechiseledModuleBlock'},transformer:function(node){
  var hooks=0;
  for(var i=0;i<node.methods.size();i++) {
   var method=node.methods.get(i);
   if(method.name!=='createAndAddEntry') continue;
   for(var n=method.instructions.getFirst();n!==null;n=n.getNext()) {
    if(n.getOpcode()===O.INVOKEVIRTUAL && n.owner==='com/google/gson/JsonObject' && n.name==='isJsonNull' && n.desc==='()Z') {
     var branch=n.getNext();while(branch!==null && branch.getOpcode()<0) branch=branch.getNext();
     if(branch===null || branch.getOpcode()!==O.IFNE) throw new Error('Unexpected Stone Zone empty-entry guard');
     n.name='size';n.desc='()I';branch.setOpcode(O.IFEQ);hooks++;
    }
   }
  }
  if(hooks!==1) throw new Error('NEST chiseling expected one guard, found '+hooks);
  return node;
 }}};
}
