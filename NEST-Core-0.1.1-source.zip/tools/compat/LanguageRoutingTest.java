import nest.compat.LanguageRouting;
import nest.compat.GeneratedAnimation;
import java.util.*;
public class LanguageRoutingTest {
 public static void main(String[] args) {
  for(String locale:Arrays.asList("en_us","de_de","ja_jp","ar_sa"))
   if(!LanguageRouting.route(Arrays.asList("en_us",locale)).equals(Collections.singletonList("en_us"))) throw new AssertionError(locale);
  Map<String,String> map=new HashMap<>();map.put("a","简体中文 铁矿石 %1$s {0} §a");map.put("brand","NEST / Farmer's Delight");
  LanguageRouting.convert(map,LanguageRouting.route(Arrays.asList("en_us","zh_tw")));
  if(!map.get("a").equals("簡體中文 鐵礦石 %1$s {0} §a")) throw new AssertionError(map);
  LanguageRouting.convert(map,LanguageRouting.route(Arrays.asList("en_us","zh_cn")));
  if(!map.get("a").equals("简体中文 铁矿石 %1$s {0} §a")) throw new AssertionError(map);
  if(!map.get("brand").equals("NEST / Farmer's Delight")) throw new AssertionError(map);
  if(!GeneratedAnimation.isSpurious("gemsrealm:block/rcd/a",128,128,"FULL",128,128,true)) throw new AssertionError("static CTM not recognized");
  if(GeneratedAnimation.isSpurious("other:block/a",128,128,"FULL",128,128,true)) throw new AssertionError("unrelated namespace");
  if(GeneratedAnimation.isSpurious("gemsrealm:block/a",128,128,"FULL",16,16,false)) throw new AssertionError("real animation changed");
  if(GeneratedAnimation.isSpurious("gemsrealm:block/a",96,128,"FULL",96,128,true)) throw new AssertionError("valid rectangular sheet changed");
  System.out.println("PASS: locale routing, Chinese conversion, tokens and Latin branding");
 }
}
