package nest.compat;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/** Called only by CookingPotResultSlot.onTake, never by inventory observation. */
public final class TutorialEvidence {
 private static final Map<Object,Boolean> POT_MEALS=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Map<Object,Boolean> ELIXIRS=Collections.synchronizedMap(new WeakHashMap<>());
 public static void elixirTake(Object player,Object stack) {
  if (itemId(stack).equals("elixirum:elixir")) ELIXIRS.put(player,true);
 }
 public static boolean consumeElixir(Object player) { return ELIXIRS.remove(player)!=null; }
 public static void potTake(Object player,Object stack) {
  if (itemId(stack).equals("minecraft:mushroom_stew")) POT_MEALS.put(player,true);
 }
 private static String itemId(Object stack) {
  try {
   Method getItem=stack.getClass().getMethod("m_41720_");
   Object registry=Class.forName("net.minecraftforge.registries.ForgeRegistries").getField("ITEMS").get(null);
   Class<?> api=Class.forName("net.minecraftforge.registries.IForgeRegistry");
   Method getKey=api.getMethod("getKey",Object.class);
   return String.valueOf(getKey.invoke(registry,getItem.invoke(stack)));
  } catch (ReflectiveOperationException e) { throw new IllegalStateException("NEST cooking-pot evidence failed",e); }
 }
 public static boolean consumePotMeal(Object player) { return POT_MEALS.remove(player)!=null; }
 private TutorialEvidence() {}
}
