function initializeCoreMod() {
 return {'nest_pot_result_evidence':{
  'target':{'type':'METHOD','class':'vectorwing.farmersdelight.common.block.entity.container.CookingPotResultSlot','methodName':'m_142406_','methodDesc':'(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;)V'},
  'transformer':function(method) {
   var Opcodes=Java.type('org.objectweb.asm.Opcodes');
   var InsnList=Java.type('org.objectweb.asm.tree.InsnList');
   var VarInsnNode=Java.type('org.objectweb.asm.tree.VarInsnNode');
   var MethodInsnNode=Java.type('org.objectweb.asm.tree.MethodInsnNode');
   var hook=new InsnList();
   hook.add(new VarInsnNode(Opcodes.ALOAD,1));hook.add(new VarInsnNode(Opcodes.ALOAD,2));
   hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC,'nest/compat/TutorialEvidence','potTake','(Ljava/lang/Object;Ljava/lang/Object;)V',false));
   method.instructions.insert(hook);return method;
  }
 },'nest_elixir_result_evidence':{
  'target':{'type':'METHOD','class':'dev.obscuria.elixirum.common.world.block.GlassCauldronInteraction$ElixirScoopUp','methodName':'interact','methodDesc':'(Ldev/obscuria/elixirum/common/world/block/entity/GlassCauldronEntity;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;'},
  'transformer':function(method) {
   var Opcodes=Java.type('org.objectweb.asm.Opcodes');
   var InsnList=Java.type('org.objectweb.asm.tree.InsnList');
   var VarInsnNode=Java.type('org.objectweb.asm.tree.VarInsnNode');
   var MethodInsnNode=Java.type('org.objectweb.asm.tree.MethodInsnNode');
   var count=0;
   for(var node=method.instructions.getFirst();node!=null;node=node.getNext()) {
    if(node instanceof MethodInsnNode && node.name==='m_36356_' && node.desc==='(Lnet/minecraft/world/item/ItemStack;)Z') {
     // Runs only on the server's successful, nonempty bottling path, before inventory insertion.
     var hook=new InsnList();hook.add(new VarInsnNode(Opcodes.ALOAD,4));hook.add(new VarInsnNode(Opcodes.ALOAD,7));
     hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC,'nest/compat/TutorialEvidence','elixirTake','(Ljava/lang/Object;Ljava/lang/Object;)V',false));
     method.instructions.insertBefore(node,hook);count++;
    }
   }
   if(count!==1)throw new Error('NEST expected one Elixirum bottling result, got '+count);
   return method;
  }
 }};
}
