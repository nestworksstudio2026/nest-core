package nest.compat;

import java.util.*;
import com.ibm.icu.text.Transliterator;

/** Locale routing uses installed assets; it does not bundle upstream language files. */
public final class LanguageRouting {
    public static List<String> route(List<String> requested) {
        String selected = requested.isEmpty() ? "en_us" : requested.get(requested.size() - 1);
        if (selected.equals("zh_tw")) return Arrays.asList("en_us", "zh_cn", "zh_tw");
        if (selected.equals("zh_cn")) return Arrays.asList("en_us", "zh_tw", "zh_cn");
        return Collections.singletonList("en_us");
    }

    public static Map<String,String> convert(Map<String,String> text, List<String> effective) {
        String selected = effective.get(effective.size() - 1);
        if (!selected.equals("zh_tw") && !selected.equals("zh_cn")) return text;
        Transliterator converter = Transliterator.getInstance(selected.equals("zh_tw")
            ? "Simplified-Traditional" : "Traditional-Simplified");
        text.replaceAll((key, value) -> converter.transliterate(value));
        return text;
    }
}
