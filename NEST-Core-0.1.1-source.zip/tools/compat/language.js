function initializeCoreMod() {
  var O = Java.type('org.objectweb.asm.Opcodes');
  var List = Java.type('org.objectweb.asm.tree.InsnList');
  var Var = Java.type('org.objectweb.asm.tree.VarInsnNode');
  var Call = Java.type('org.objectweb.asm.tree.MethodInsnNode');
  var Insn = Java.type('org.objectweb.asm.tree.InsnNode');
  return {'nest_language_routing': {
    target: {type:'CLASS',name:'net.minecraft.client.resources.language.ClientLanguage'},
    transformer: function(node) {
      var hooks=0;
      for(var i=0;i<node.methods.size();i++) {
        var method=node.methods.get(i);
        if(method.desc!=='(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Z)Lnet/minecraft/client/resources/language/ClientLanguage;') continue;
        var code=method.instructions;
        var head=new List();
        head.add(new Var(O.ALOAD,1));
        head.add(new Call(O.INVOKESTATIC,'nest/compat/LanguageRouting','route','(Ljava/util/List;)Ljava/util/List;',false));
        head.add(new Var(O.ASTORE,1));
        head.add(new Insn(O.ICONST_0));
        head.add(new Var(O.ISTORE,2));
        code.insert(head);
        for(var n=code.getFirst();n!==null;n=n.getNext()) {
          if(n.getOpcode()===O.INVOKESTATIC && n.owner==='com/google/common/collect/ImmutableMap' && n.name==='copyOf' && n.desc==='(Ljava/util/Map;)Lcom/google/common/collect/ImmutableMap;') {
            var tail=new List();
            tail.add(new Var(O.ALOAD,1));
            tail.add(new Call(O.INVOKESTATIC,'nest/compat/LanguageRouting','convert','(Ljava/util/Map;Ljava/util/List;)Ljava/util/Map;',false));
            code.insertBefore(n,tail);hooks++;
          }
        }
      }
      if(hooks!==1) throw new Error('NEST language routing expected one hook, found '+hooks);
      return node;
    }
  }};
}
