function initializeCoreMod() {
 var O=Java.type('org.objectweb.asm.Opcodes');
 var List=Java.type('org.objectweb.asm.tree.InsnList');
 var Var=Java.type('org.objectweb.asm.tree.VarInsnNode');
 var Call=Java.type('org.objectweb.asm.tree.MethodInsnNode');
 var Type=Java.type('org.objectweb.asm.tree.TypeInsnNode');
 return {'nest_static_ctm':{target:{type:'CLASS',name:'com.supermartijn642.fusion.texture.types.connecting.ConnectingTextureType'},transformer:function(node){
  var hooks=0;
  for(var i=0;i<node.methods.size();i++) {
   var method=node.methods.get(i);
   if(method.name!=='createTexture' || method.desc.indexOf('ConnectingTextureData;')<0) continue;
   for(var n=method.instructions.getFirst();n!==null;n=n.getNext()) {
    if(n.getOpcode()===O.INVOKEINTERFACE && n.name==='getAnimationMetadata') {
     var hook=new List();hook.add(new Var(O.ALOAD,2));hook.add(new Var(O.ALOAD,3));
     hook.add(new Call(O.INVOKESTATIC,'nest/compat/GeneratedAnimation','sanitize','(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;',false));
     hook.add(new Type(O.CHECKCAST,'net/minecraft/client/resources/metadata/animation/AnimationMetadataSection'));
     method.instructions.insert(n,hook);hooks++;
    }
   }
  }
  if(hooks!==1) throw new Error('NEST CTM expected one animation hook, found '+hooks);
  return node;
 }}};
}
