package nest.compat;

import java.lang.reflect.*;
import java.util.List;

/** Only discard the empty, full-sheet animation generated for static CTM sheets. */
public final class GeneratedAnimation {
 public static boolean isSpurious(String id, int width, int height, String layout,
                                  int frameWidth, int frameHeight, boolean emptyFrames) {
  return (id.startsWith("everycomp:") || id.startsWith("gemsrealm:") || id.startsWith("stonezone:"))
      && layout.equals("FULL") && width == height && frameWidth == width
      && frameHeight == height && emptyFrames;
 }
 private static Object field(Object value, String name) throws ReflectiveOperationException {
  Field f=value.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(value);
 }
 public static Object sanitize(Object animation, Object context, Object data) {
  if(animation==null) return null;
  try {
   Class<?> ctx=Class.forName("com.supermartijn642.fusion.api.texture.custom.TextureCreationContext");
   Class<?> type=Class.forName("com.supermartijn642.fusion.api.texture.types.connecting.ConnectingTextureData");
   String id=ctx.getMethod("getIdentifier").invoke(context).toString();
   int w=(Integer)ctx.getMethod("getImageWidth").invoke(context);
   int h=(Integer)ctx.getMethod("getImageHeight").invoke(context);
   String layout=type.getMethod("getLayout").invoke(data).toString();
   if(isSpurious(id,w,h,layout,(Integer)field(animation,"f_119014_"),
        (Integer)field(animation,"f_119015_"),((List<?>)field(animation,"f_119013_")).isEmpty())) {
    System.out.println("[NEST CTM] Removed spurious full-sheet animation: "+id);
    return null;
   }
  } catch(ReflectiveOperationException ex) { throw new IllegalStateException("NEST static CTM compatibility failed",ex); }
  return animation;
 }
}
