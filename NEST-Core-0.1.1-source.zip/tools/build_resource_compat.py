"""Build NEST Core: resource integration, locale routing and tutorial evidence."""
import json,zipfile,shutil,subprocess,os
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'build/resource-compat';O.mkdir(parents=True,exist_ok=True)
SOURCE='''function initializeCoreMod() {
  var Opcodes = Java.type('org.objectweb.asm.Opcodes');
  var MethodInsnNode = Java.type('org.objectweb.asm.tree.MethodInsnNode');
  var ASMAPI = Java.type('net.minecraftforge.coremod.api.ASMAPI');
  return {
    'nest_acorn_repair': {
      'target': {'type': 'CLASS', 'name': 'io.github.bonsaistudi0s.crittersandcompanions.common.registry.CACArmorMaterials'},
      'transformer': function(node) {
        var changed = 0;
        for (var m = 0; m < node.methods.size(); m++) {
          var method = node.methods.get(m);
          var code = method.instructions;
          for (var insn = code.getFirst(); insn !== null; insn = insn.getNext()) {
            if (insn.getOpcode() !== Opcodes.GETSTATIC ||
                insn.owner !== 'io/github/bonsaistudi0s/crittersandcompanions/common/registry/CACItems' ||
                insn.name !== 'ACORN') continue;
            var next = insn.getNext();
            while (next !== null && next.getOpcode() < 0) next = next.getNext();
            if (next === null || next.name !== 'get' || next.desc !== '()Ljava/lang/Object;' ||
                next.owner !== 'dev/architectury/registry/registries/RegistrySupplier') {
              throw new Error('NEST acorn compatibility: unsupported bytecode; review the installed mod version');
            }
            insn.owner = 'net/mcreator/pawsandclaws/init/PawsAndClawsModItems';
            insn.desc = 'Lnet/minecraftforge/registries/RegistryObject;';
            code.set(next, new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
              'net/minecraftforge/registries/RegistryObject', 'get', '()Ljava/lang/Object;', false));
            changed++;
          }
        }
        if (changed !== 1) throw new Error('NEST acorn compatibility: expected one repair-material reference, got ' + changed);
        ASMAPI.log('INFO', '[NEST] Canonical acorn repair bridge applied: ' + changed);
        return node;
      }
    }
  };
}
'''
(O/'acorn.js').write_text(SOURCE,encoding='utf8')
meta='''modLoader="lowcodefml"
loaderVersion="[47,)"
license="MIT"
[[mods]]
modId="nest_resource_compat"
version="0.1.1"
displayName="NEST Core"
description="Core integration for NEST: resource repair, language routing, generated building fixes and tutorial operation evidence."
[[dependencies.nest_resource_compat]]
modId="crittersandcompanions"
mandatory=true
versionRange="[2.7.1,2.7.2)"
ordering="NONE"
side="BOTH"
[[dependencies.nest_resource_compat]]
modId="paws_and_claws"
mandatory=true
versionRange="[0,)"
ordering="NONE"
side="BOTH"
'''
license_text='''MIT License

Copyright (c) 2026 NEST contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''
jar=O/'nest-core-0.1.1.jar'
libraries=Path(os.environ.get('NEST_MC_LIBRARIES',str(Path.home()/'curseforge/minecraft/Install/libraries')))
icu=libraries/'com/ibm/icu/icu4j/71.1/icu4j-71.1.jar'
javac=os.environ.get('JAVAC') or shutil.which('javac') or 'C:/Program Files/Java/jdk-21.0.12/bin/javac.exe'
classes=O/'classes';classes.mkdir(exist_ok=True)
subprocess.run([javac,'--release','17','-encoding','UTF-8','-cp',str(icu),'-d',str(classes),str(R/'tools/compat/LanguageRouting.java'),str(R/'tools/compat/GeneratedAnimation.java'),str(R/'tools/compat/TutorialEvidence.java'),str(R/'tools/compat/ResourceRepairs.java')],check=True)
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'NEST compatibility resources'}}))
 z.writestr('META-INF/mods.toml',meta);z.writestr('META-INF/coremods.json',json.dumps({'nest_acorn':'coremods/acorn.js','nest_language':'coremods/language.js','nest_ctm':'coremods/fusion.js','nest_chiseling':'coremods/chiseling.js','nest_tutorial':'coremods/quest_evidence.js','nest_resources':'coremods/resource_repairs.js'}))
 z.writestr('coremods/acorn.js',SOURCE);z.writestr('LICENSE',license_text)
 z.write(R/'tools/compat/language.js','coremods/language.js')
 z.write(R/'tools/compat/fusion.js','coremods/fusion.js')
 z.write(R/'tools/compat/chiseling.js','coremods/chiseling.js')
 z.write(R/'tools/compat/quest_evidence.js','coremods/quest_evidence.js')
 z.write(R/'tools/compat/resource_repairs.js','coremods/resource_repairs.js')
 for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes).as_posix())
if '--apply' in __import__('sys').argv:
 for base in [R/'pack',R/'build/full-audit/test-client']:
  d=base/'mods'/jar.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(jar,d)
print(jar)
